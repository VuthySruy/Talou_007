

public class PlayerSpawnPointManagerPrototype : SpawnPointManagerPrototype<PlayerSpawnPointPrototype> {

}
